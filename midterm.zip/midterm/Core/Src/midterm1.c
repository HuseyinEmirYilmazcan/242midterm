/*
 * midterm1.c
 *
 *  Created on: Apr 12, 2023
 *      Author: Emir
 */
#include <STM32F407xx.h>
int main() {
RCC ->AHB1ENR =0x00000008U;
 RCC -> APB2LPENR |= RCC_APB2LPENR_TIM1LPEN_Msk;
 TIM1 -> CNT = 0x0U;
 TIM1 -> PSC = 0X2U;
 TIM1 -> ARR = 0x103E7U;
 TIM1 -> CR1 = 0x1U;
 while(){
}
TIM1-> CNT = 0X1U;
RCC ->AHB1ENR =0x00000008U;
GPIOD -> MODER =0x40000000U;
GPIOD -> ODR = 0X4000U;

//LED
}
